"""

   TESLA API Library for Python

"""

from .myTesla import connect

__version__ = "1.3.0"
